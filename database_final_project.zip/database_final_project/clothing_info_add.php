<?php
    include "db_conn.php";
    
    if (empty($_POST['id'])) {
        die('請輸入 id');
    }
  
    // 清理並儲存接收到的資料
    $id = trim($_POST["id"]);
    $name = trim($_POST["name"]);
    $description = trim($_POST["description"]);
    $price = trim($_POST["price"]);
    $store_name = trim($_POST["store_name"]);
    $supplier_name = trim($_POST["supplier_name"]);

    // 除錯用，可以看到實際收到的資料
    echo "接收到的資料：<br>";
    echo "ID: '$id'<br>";
    echo "Name: '$name'<br>";
    echo "Description: '$description'<br>";
    echo "Price: '$price'<br>";
    echo "Store: '$store_name'<br>";
    echo "Supplier: '$supplier_name'<br>";

    $query = "INSERT INTO cloth (id, name, description, price, store_name, supplier_name) VALUES (?, ?, ?, ?, ?, ?)";
    
    $stmt = $db->prepare($query);
    $stmt->bind_param("sssiss", $id, $name, $description, $price, $store_name, $supplier_name);
    
    if (!$stmt->execute()) {
        die('資料儲存失敗：' . $stmt->error);
    }

    header('Location: clothing_info.php');
    exit();
?>